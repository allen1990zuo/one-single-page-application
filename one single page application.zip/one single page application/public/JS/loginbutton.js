ECE9065_Lab1.controller('mainController', function ($scope, $log) {
       $scope.login=function()
       {
          
          w = window.open(url, 'window', 'status=0,menubar=0,resizable=1,width=500,height=800;');
       }
      });
